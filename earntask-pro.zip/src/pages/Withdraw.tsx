import React, { useState } from 'react';
import { useAuth } from '@/src/components/AuthContext';
import { supabase } from '@/src/lib/supabase';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Building2, 
  Wallet, 
  AlertCircle, 
  Loader2,
  ArrowLeft,
  Info,
  CheckCircle2
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function Withdraw() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');

  const MIN_WITHDRAWAL = 20;

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;

    const withdrawAmount = parseFloat(amount);

    if (withdrawAmount < MIN_WITHDRAWAL) {
      toast.error(`Minimum withdrawal is $${MIN_WITHDRAWAL}`);
      return;
    }

    if (withdrawAmount > profile.balance) {
      toast.error('Insufficient balance');
      return;
    }

    setLoading(true);

    try {
      // 1. Create withdrawal record
      const { error: withdrawError } = await supabase
        .from('withdrawals')
        .insert([
          {
            user_id: user.id,
            amount: withdrawAmount,
            bank_name: bankName,
            account_number: accountNumber,
            account_name: accountName,
            status: 'pending',
          },
        ]);

      if (withdrawError) throw withdrawError;

      // 2. Deduct from balance
      const { error: balanceError } = await supabase
        .from('profiles')
        .update({ balance: profile.balance - withdrawAmount })
        .eq('id', user.id);

      if (balanceError) throw balanceError;

      await refreshProfile();
      toast.success('Withdrawal request submitted successfully!');
      navigate('/earnings');
    } catch (err: any) {
      toast.error(err.message || 'Failed to process withdrawal');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-2xl">
        <Button variant="ghost" onClick={() => navigate('/earnings')} className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Earnings
        </Button>
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Withdraw Funds</h1>
          <p className="text-muted-foreground">Transfer your earnings to your bank account.</p>
        </div>

        <div className="grid gap-8">
          {/* Balance Card */}
          <Card className="bg-primary text-primary-foreground">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium opacity-80">Withdrawable Balance</p>
                  <h3 className="text-4xl font-bold">${profile?.balance?.toFixed(2) || '0.00'}</h3>
                </div>
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20">
                  <Wallet className="h-8 w-8" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Withdrawal Form */}
          <Card>
            <CardHeader>
              <CardTitle>Withdrawal Details</CardTitle>
              <CardDescription>Enter your bank information correctly to avoid delays.</CardDescription>
            </CardHeader>
            <form onSubmit={handleWithdraw}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount to Withdraw ($)</Label>
                  <Input 
                    id="amount" 
                    type="number" 
                    step="0.01"
                    placeholder="0.00" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required 
                  />
                  <p className="text-[10px] text-muted-foreground">Minimum withdrawal: ${MIN_WITHDRAWAL}</p>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name</Label>
                    <Input 
                      id="bankName" 
                      placeholder="e.g. Chase, OPay, Kuda" 
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number</Label>
                    <Input 
                      id="accountNumber" 
                      placeholder="10 digits" 
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      required 
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="accountName">Account Name</Label>
                  <Input 
                    id="accountName" 
                    placeholder="Full name on account" 
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    required 
                  />
                </div>

                <div className="flex gap-3 rounded-lg bg-blue-500/10 p-4 text-sm text-blue-700 border border-blue-500/20">
                  <Info className="h-5 w-5 shrink-0" />
                  <p>
                    Withdrawals are processed within 24-48 hours. Please ensure your bank details are accurate.
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" className="w-full h-12 text-lg font-bold" disabled={loading || !profile || profile.balance < MIN_WITHDRAWAL}>
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Confirm Withdrawal
                </Button>
              </CardFooter>
            </form>
          </Card>

          {/* Trust Badges */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex items-center gap-3 rounded-lg border p-4 text-sm">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <span>Secure encrypted transactions</span>
            </div>
            <div className="flex items-center gap-3 rounded-lg border p-4 text-sm">
              <AlertCircle className="h-5 w-5 text-primary" />
              <span>Verified payout system</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
