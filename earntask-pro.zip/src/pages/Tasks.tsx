import React, { useState, useEffect } from 'react';
import { useAuth } from '@/src/components/AuthContext';
import { supabase, Task } from '@/src/lib/supabase';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  CheckCircle2, 
  ExternalLink, 
  Clock, 
  AlertCircle, 
  Twitter, 
  Download, 
  FileText,
  Loader2,
  Upload
} from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function Tasks() {
  const { user, profile } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [proofUrl, setProofUrl] = useState('');
  const [proofFile, setProofFile] = useState<File | null>(null);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const { data, error } = await supabase
          .from('tasks')
          .select('*')
          .eq('status', 'active')
          .order('created_at', { ascending: false });

        if (error) throw error;
        setTasks(data || []);
      } catch (err) {
        console.error('Error fetching tasks:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchTasks();
  }, []);

  const handleSubmitTask = async () => {
    if (!user || !selectedTask) return;
    if (!proofFile && !proofUrl) {
      toast.error('Please provide proof of completion');
      return;
    }

    setSubmitting(true);

    try {
      let finalProofUrl = proofUrl;

      if (proofFile) {
        const fileExt = proofFile.name.split('.').pop();
        const fileName = `${user.id}-${selectedTask.id}-${Date.now()}.${fileExt}`;
        const filePath = `task-proofs/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('proofs')
          .upload(filePath, proofFile);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('proofs')
          .getPublicUrl(filePath);
        
        finalProofUrl = publicUrl;
      }

      const { error } = await supabase
        .from('user_tasks')
        .insert([
          {
            user_id: user.id,
            task_id: selectedTask.id,
            proof_url: finalProofUrl,
            status: 'pending',
            reward: selectedTask.reward,
          },
        ]);

      if (error) throw error;

      toast.success('Task submitted for review!');
      setSelectedTask(null);
      setProofFile(null);
      setProofUrl('');
    } catch (err: any) {
      toast.error(err.message || 'Failed to submit task');
    } finally {
      setSubmitting(false);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'social': return <Twitter className="h-5 w-5" />;
      case 'download': return <Download className="h-5 w-5" />;
      case 'survey': return <FileText className="h-5 w-5" />;
      default: return <CheckCircle2 className="h-5 w-5" />;
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Available Tasks</h1>
        <p className="text-muted-foreground">Complete tasks to earn rewards. Each task is reviewed manually.</p>
      </div>

      <Tabs defaultValue="all" className="space-y-8">
        <TabsList>
          <TabsTrigger value="all">All Tasks</TabsTrigger>
          <TabsTrigger value="social">Social Media</TabsTrigger>
          <TabsTrigger value="download">App Downloads</TabsTrigger>
          <TabsTrigger value="survey">Surveys</TabsTrigger>
        </TabsList>

        {['all', 'social', 'download', 'survey'].map((tab) => (
          <TabsContent key={tab} value={tab} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {tasks
                .filter(t => tab === 'all' || t.type === tab)
                .map((task) => (
                <Card key={task.id} className="flex flex-col overflow-hidden transition-all hover:shadow-lg">
                  <CardHeader className="pb-4">
                    <div className="mb-2 flex items-center justify-between">
                      <Badge variant="secondary" className="flex items-center gap-1 uppercase tracking-wider text-[10px]">
                        {getIcon(task.type)}
                        {task.type}
                      </Badge>
                      <div className="text-lg font-bold text-primary">${task.reward.toFixed(2)}</div>
                    </div>
                    <CardTitle className="line-clamp-1">{task.title}</CardTitle>
                    <CardDescription className="line-clamp-2">{task.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 pb-4">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>Review time: ~24 hours</span>
                    </div>
                  </CardContent>
                  <CardFooter className="border-t bg-muted/30 pt-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="w-full" onClick={() => setSelectedTask(task)}>
                          Complete Task
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                          <DialogTitle>{task.title}</DialogTitle>
                          <DialogDescription>
                            Follow the instructions carefully to ensure your reward is approved.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-6 py-4">
                          <div className="rounded-lg bg-muted p-4 space-y-2">
                            <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Instructions:</h4>
                            <p className="text-sm">{task.description}</p>
                            <Button variant="link" className="h-auto p-0 text-primary" asChild>
                              <a href="#" target="_blank" rel="noopener noreferrer">
                                Open Task Link <ExternalLink className="ml-1 h-3 w-3" />
                              </a>
                            </Button>
                          </div>

                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label>Upload Screenshot Proof</Label>
                              <div className="flex items-center gap-4">
                                <Button variant="outline" className="w-full relative overflow-hidden">
                                  <Upload className="mr-2 h-4 w-4" />
                                  {proofFile ? proofFile.name : 'Choose Image'}
                                  <input 
                                    type="file" 
                                    className="absolute inset-0 cursor-pointer opacity-0" 
                                    accept="image/*"
                                    onChange={(e) => {
                                      if (e.target.files?.[0]) setProofFile(e.target.files[0]);
                                    }}
                                  />
                                </Button>
                              </div>
                            </div>
                            
                            <div className="relative">
                              <div className="absolute inset-0 flex items-center">
                                <span className="w-full border-t" />
                              </div>
                              <div className="relative flex justify-center text-xs uppercase">
                                <span className="bg-background px-2 text-muted-foreground">Or provide link</span>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="proofUrl">Proof URL / Username</Label>
                              <Input 
                                id="proofUrl" 
                                placeholder="e.g. twitter.com/yourhandle" 
                                value={proofUrl}
                                onChange={(e) => setProofUrl(e.target.value)}
                              />
                            </div>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setSelectedTask(null)}>Cancel</Button>
                          <Button onClick={handleSubmitTask} disabled={submitting}>
                            {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            Submit Task
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardFooter>
                </Card>
              ))}
              
              {tasks.filter(t => tab === 'all' || t.type === tab).length === 0 && (
                <div className="col-span-full py-12 text-center">
                  <div className="mb-4 flex justify-center">
                    <AlertCircle className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-bold">No tasks available</h3>
                  <p className="text-muted-foreground">Check back later for new opportunities.</p>
                </div>
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
