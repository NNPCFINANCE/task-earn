import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  UserPlus, 
  CreditCard, 
  CheckSquare, 
  Wallet, 
  ArrowRight,
  ShieldCheck,
  Zap,
  TrendingUp
} from 'lucide-react';
import { motion } from 'motion/react';

export default function HowItWorks() {
  const steps = [
    {
      title: 'Create Your Account',
      description: 'Sign up in seconds with your email. It is free to join and explore the platform.',
      icon: UserPlus,
      color: 'bg-blue-500',
    },
    {
      title: 'Choose a Plan',
      description: 'Select a subscription plan that fits your earning goals. Higher plans unlock more tasks.',
      icon: CreditCard,
      color: 'bg-primary',
    },
    {
      title: 'Complete Tasks',
      description: 'Access your dashboard and start completing social media tasks, surveys, and more.',
      icon: CheckSquare,
      color: 'bg-green-500',
    },
    {
      title: 'Withdraw Earnings',
      description: 'Once your tasks are approved, withdraw your balance directly to your bank account.',
      icon: Wallet,
      color: 'bg-yellow-500',
    },
  ];

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="mb-16 text-center">
        <h1 className="mb-4 text-4xl font-extrabold tracking-tight md:text-6xl">How It Works</h1>
        <p className="mx-auto max-w-2xl text-xl text-muted-foreground">
          EarnTask Pro makes it easy to earn extra income online. Follow our simple 4-step process to get started.
        </p>
      </div>

      <div className="relative">
        {/* Connection Line (Desktop) */}
        <div className="absolute left-1/2 top-0 hidden h-full w-1 -translate-x-1/2 bg-muted md:block" />

        <div className="space-y-12 md:space-y-24">
          {steps.map((step, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className={`flex flex-col items-center gap-8 md:flex-row ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}
            >
              <div className="flex-1 text-center md:text-left">
                <div className={`mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl ${step.color} text-white shadow-lg`}>
                  <step.icon className="h-8 w-8" />
                </div>
                <h2 className="mb-4 text-3xl font-bold">{index + 1}. {step.title}</h2>
                <p className="text-lg text-muted-foreground">{step.description}</p>
              </div>
              
              <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-full bg-background border-4 border-muted font-bold text-primary">
                {index + 1}
              </div>
              
              <div className="flex-1 hidden md:block">
                <div className="rounded-3xl border bg-card p-8 shadow-xl">
                  <div className="mb-4 flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-red-500" />
                    <div className="h-3 w-3 rounded-full bg-yellow-500" />
                    <div className="h-3 w-3 rounded-full bg-green-500" />
                  </div>
                  <div className="space-y-4">
                    <div className="h-4 w-3/4 rounded bg-muted" />
                    <div className="h-4 w-1/2 rounded bg-muted" />
                    <div className="h-24 w-full rounded bg-muted/50" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="mt-32 rounded-3xl bg-muted/30 p-8 md:p-16">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-3">
          <div className="text-center">
            <div className="mb-4 flex justify-center text-primary">
              <ShieldCheck className="h-12 w-12" />
            </div>
            <h3 className="mb-2 text-xl font-bold">Secure Platform</h3>
            <p className="text-sm text-muted-foreground">Your data and earnings are protected by industry-leading security protocols.</p>
          </div>
          <div className="text-center">
            <div className="mb-4 flex justify-center text-primary">
              <Zap className="h-12 w-12" />
            </div>
            <h3 className="mb-2 text-xl font-bold">Fast Payouts</h3>
            <p className="text-sm text-muted-foreground">We process withdrawals within 24-48 hours, directly to your bank account.</p>
          </div>
          <div className="text-center">
            <div className="mb-4 flex justify-center text-primary">
              <TrendingUp className="h-12 w-12" />
            </div>
            <h3 className="mb-2 text-xl font-bold">Scalable Earnings</h3>
            <p className="text-sm text-muted-foreground">The more you contribute, the higher your earning potential becomes.</p>
          </div>
        </div>
      </div>

      <div className="mt-20 text-center">
        <h2 className="mb-8 text-3xl font-bold">Ready to join the community?</h2>
        <Link to="/signup">
          <Button size="lg" className="h-14 px-10 text-lg font-bold">
            Get Started Today <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </Link>
      </div>
    </div>
  );
}
