import React from 'react';
import { useAuth } from '@/src/components/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Wallet, 
  CheckSquare, 
  TrendingUp, 
  Clock, 
  ArrowUpRight, 
  Zap,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

export default function Dashboard() {
  const { profile } = useAuth();

  const stats = [
    {
      title: 'Available Balance',
      value: `$${profile?.balance?.toFixed(2) || '0.00'}`,
      icon: Wallet,
      color: 'text-primary',
      bg: 'bg-primary/10',
    },
    {
      title: 'Tasks Completed',
      value: '24',
      icon: CheckSquare,
      color: 'text-green-500',
      bg: 'bg-green-500/10',
    },
    {
      title: 'Pending Earnings',
      value: '$12.50',
      icon: Clock,
      color: 'text-yellow-500',
      bg: 'bg-yellow-500/10',
    },
    {
      title: 'Total Earned',
      value: '$156.00',
      icon: TrendingUp,
      color: 'text-blue-500',
      bg: 'bg-blue-500/10',
    },
  ];

  const recentTasks = [
    { id: 1, title: 'Follow on Twitter', reward: 0.50, status: 'approved', date: '2 hours ago' },
    { id: 2, title: 'Download App X', reward: 2.00, status: 'pending', date: '5 hours ago' },
    { id: 3, title: 'Complete Survey', reward: 1.50, status: 'approved', date: '1 day ago' },
  ];

  if (profile?.plan === 'free') {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-6 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-yellow-500/10 text-yellow-500">
              <AlertCircle className="h-12 w-12" />
            </div>
          </div>
          <h1 className="mb-4 text-3xl font-bold">Subscription Required</h1>
          <p className="mb-8 text-lg text-muted-foreground">
            You are currently on the Free plan. To start earning and access tasks, you need to subscribe to one of our premium plans.
          </p>
          <div className="flex flex-col justify-center gap-4 sm:flex-row">
            <Link to="/pricing">
              <Button size="lg" className="h-12 px-8">View Pricing Plans</Button>
            </Link>
            <Link to="/how-it-works">
              <Button size="lg" variant="outline" className="h-12 px-8">Learn How It Works</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back, {profile?.full_name?.split(' ')[0]}!</h1>
          <p className="text-muted-foreground">Here's what's happening with your earnings today.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-bold text-primary border border-primary/20 shadow-sm">
            <Zap className="h-4 w-4" />
            <span>{profile?.plan?.toUpperCase()} PLAN</span>
          </div>
          <Link to="/tasks">
            <Button>
              <CheckSquare className="mr-2 h-4 w-4" />
              Find Tasks
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="overflow-hidden border-none shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <h3 className="mt-1 text-2xl font-bold">{stat.value}</h3>
                  </div>
                  <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${stat.bg} ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Recent Activity */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest task completions and earnings.</CardDescription>
            </div>
            <Link to="/earnings">
              <Button variant="ghost" size="sm">
                View All <ArrowUpRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTasks.map((task) => (
                <div key={task.id} className="flex items-center justify-between rounded-lg border p-4 transition-colors hover:bg-muted/50">
                  <div className="flex items-center gap-4">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full ${task.status === 'approved' ? 'bg-green-500/10 text-green-500' : 'bg-yellow-500/10 text-yellow-500'}`}>
                      {task.status === 'approved' ? <ShieldCheck className="h-5 w-5" /> : <Clock className="h-5 w-5" />}
                    </div>
                    <div>
                      <div className="font-semibold">{task.title}</div>
                      <div className="text-xs text-muted-foreground">{task.date}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-primary">+${task.reward.toFixed(2)}</div>
                    <div className={`text-[10px] font-bold uppercase tracking-wider ${task.status === 'approved' ? 'text-green-500' : 'text-yellow-500'}`}>
                      {task.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions / Tips */}
        <div className="space-y-6">
          <Card className="bg-primary text-primary-foreground">
            <CardHeader>
              <CardTitle className="text-xl">Daily Tip</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm opacity-90">
                Complete at least 5 tasks daily to maintain your "Top Earner" status and get access to exclusive high-reward surveys.
              </p>
              <Button variant="secondary" className="mt-4 w-full">Learn More</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Refer & Earn</CardTitle>
              <CardDescription>Invite friends and earn 10% of their task rewards.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 rounded-md border bg-muted p-2">
                <span className="flex-1 truncate text-xs font-mono">earntask.pro/ref/user123</span>
                <Button size="sm" variant="ghost" className="h-8">Copy</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
