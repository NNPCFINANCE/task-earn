import React from 'react';
import { useAuth } from '@/src/components/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Mail, 
  ShieldCheck, 
  Calendar, 
  Zap,
  Settings,
  LogOut
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Your Profile</h1>
          <Button variant="outline" onClick={handleSignOut}>
            <LogOut className="mr-2 h-4 w-4" /> Sign Out
          </Button>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {/* Left Column: User Info */}
          <div className="space-y-6">
            <Card className="overflow-hidden">
              <div className="h-24 bg-primary" />
              <CardContent className="relative pt-12 text-center">
                <div className="absolute -top-12 left-1/2 flex h-24 w-24 -translate-x-1/2 items-center justify-center rounded-full border-4 border-background bg-muted text-muted-foreground">
                  <User className="h-12 w-12" />
                </div>
                <h2 className="text-xl font-bold">{profile?.full_name}</h2>
                <p className="text-sm text-muted-foreground">{profile?.email}</p>
                <div className="mt-4 flex justify-center">
                  <Badge variant="secondary" className="uppercase tracking-wider">
                    {profile?.plan} Plan
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Account Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{profile?.email}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Joined {new Date(profile?.created_at || '').toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <ShieldCheck className="h-4 w-4 text-muted-foreground" />
                  <span>Status: <span className="font-bold text-green-500 uppercase">{profile?.status}</span></span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Settings & Subscription */}
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Subscription Status</CardTitle>
                    <CardDescription>Manage your current earning plan.</CardDescription>
                  </div>
                  <Zap className="h-8 w-8 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-xl border bg-muted/30 p-6">
                  <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                    <div>
                      <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Current Plan</div>
                      <div className="text-2xl font-bold uppercase">{profile?.plan}</div>
                    </div>
                    <Button onClick={() => navigate('/pricing')}>Upgrade Plan</Button>
                  </div>
                  <div className="mt-6 grid grid-cols-2 gap-4 border-t pt-6">
                    <div>
                      <div className="text-xs text-muted-foreground uppercase">Daily Task Limit</div>
                      <div className="font-bold">
                        {profile?.plan === 'free' ? '0' : profile?.plan === 'starter' ? '5' : profile?.plan === 'growth' ? '15' : 'Unlimited'}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground uppercase">Withdrawal Frequency</div>
                      <div className="font-bold">
                        {profile?.plan === 'pro' ? 'Instant' : profile?.plan === 'growth' ? 'Daily' : 'Weekly'}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Update your personal information and security preferences.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Full Name</label>
                    <input 
                      type="text" 
                      defaultValue={profile?.full_name || ''}
                      className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email Address</label>
                    <input 
                      type="email" 
                      defaultValue={profile?.email || ''}
                      disabled
                      className="w-full rounded-md border bg-muted px-3 py-2 text-sm cursor-not-allowed"
                    />
                  </div>
                </div>
                <Button variant="outline">
                  <Settings className="mr-2 h-4 w-4" /> Save Changes
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
