import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/src/components/AuthContext';
import { supabase } from '@/src/lib/supabase';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Building2, 
  Copy, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  Loader2,
  ArrowLeft,
  Info,
  ShieldCheck
} from 'lucide-react';
import { toast } from 'sonner';

export default function Payment() {
  const [searchParams] = useSearchParams();
  const planId = searchParams.get('plan') || 'starter';
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [payerName, setPayerName] = useState('');
  const [reference, setReference] = useState('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [uniqueAmount, setUniqueAmount] = useState(0);

  const plans: Record<string, { name: string, price: number }> = {
    starter: { name: 'Starter', price: 10 },
    growth: { name: 'Growth', price: 25 },
    pro: { name: 'Pro', price: 50 },
  };

  const selectedPlan = plans[planId] || plans.starter;

  useEffect(() => {
    // Generate a unique amount for easier verification (e.g., $10.12)
    const randomCents = Math.floor(Math.random() * 100) / 100;
    setUniqueAmount(selectedPlan.price + randomCents);
    
    // Generate a unique reference
    const ref = 'ETP-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    setReference(ref);
  }, [selectedPlan.price]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!proofFile) {
      toast.error('Please upload proof of payment');
      return;
    }

    setLoading(true);

    try {
      // 1. Upload proof to Supabase Storage
      const fileExt = proofFile.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const filePath = `payment-proofs/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('proofs')
        .upload(filePath, proofFile);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('proofs')
        .getPublicUrl(filePath);

      // 2. Create payment record
      const { error: paymentError } = await supabase
        .from('payments')
        .insert([
          {
            user_id: user.id,
            plan_id: planId,
            amount: uniqueAmount,
            reference: reference,
            payer_name: payerName,
            proof_url: publicUrl,
            status: 'pending',
          },
        ]);

      if (paymentError) throw paymentError;

      toast.success('Payment submitted for verification!');
      navigate('/profile');
    } catch (err: any) {
      toast.error(err.message || 'Failed to submit payment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => navigate('/pricing')} className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Pricing
        </Button>
        <h1 className="text-3xl font-bold tracking-tight">Complete Your Subscription</h1>
        <p className="text-muted-foreground">Follow the steps below to activate your {selectedPlan.name} plan.</p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* Step 1: Payment Details */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2 text-primary font-bold uppercase tracking-wider text-xs">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground">1</span>
                Step One: Transfer Funds
              </div>
              <CardTitle className="text-xl">Bank Transfer Details</CardTitle>
              <CardDescription>Transfer the exact amount to the account below.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg bg-muted/50 p-6 space-y-4">
                <div className="flex justify-between items-center border-b pb-3">
                  <span className="text-sm text-muted-foreground">Bank Name</span>
                  <div className="flex items-center gap-2 font-bold">
                    <Building2 className="h-4 w-4 text-primary" />
                    Global Trust Bank (OPay)
                  </div>
                </div>
                <div className="flex justify-between items-center border-b pb-3">
                  <span className="text-sm text-muted-foreground">Account Number</span>
                  <div className="flex items-center gap-2 font-bold font-mono">
                    8123456789
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleCopy('8123456789')}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="flex justify-between items-center border-b pb-3">
                  <span className="text-sm text-muted-foreground">Account Name</span>
                  <span className="font-bold uppercase">EarnTask Pro Ltd</span>
                </div>
                <div className="flex justify-between items-center pt-1">
                  <span className="text-sm text-muted-foreground">Exact Amount</span>
                  <div className="text-2xl font-extrabold text-primary">
                    ${uniqueAmount.toFixed(2)}
                    <Button variant="ghost" size="icon" className="h-6 w-6 ml-2" onClick={() => handleCopy(uniqueAmount.toFixed(2))}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 rounded-lg bg-yellow-500/10 p-4 text-sm text-yellow-700 border border-yellow-500/20">
                <Info className="h-5 w-5 shrink-0" />
                <p>
                  <strong>Important:</strong> Please transfer the <strong>EXACT</strong> amount including cents. This helps our system verify your payment instantly.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Why manual payment?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                To keep our platform secure and avoid high processing fees (which we pass on to you as higher task rewards), we use a manual verification system. Our team reviews payments 24/7, and most accounts are activated within 15-30 minutes.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Step 2: Submission Form */}
        <div className="space-y-6">
          <Card className="border-primary/20 shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-2 text-primary font-bold uppercase tracking-wider text-xs">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground">2</span>
                Step Two: Submit Proof
              </div>
              <CardTitle className="text-xl">Payment Confirmation</CardTitle>
              <CardDescription>Fill in the details from your transfer receipt.</CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="payerName">Payer Name (on Bank Account)</Label>
                  <Input 
                    id="payerName" 
                    placeholder="e.g. John Doe" 
                    value={payerName}
                    onChange={(e) => setPayerName(e.target.value)}
                    required 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="reference">Payment Reference (Used in Bank App)</Label>
                  <div className="flex gap-2">
                    <Input 
                      id="reference" 
                      value={reference}
                      readOnly
                      className="bg-muted font-mono"
                    />
                    <Button type="button" variant="outline" size="icon" onClick={() => handleCopy(reference)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-[10px] text-muted-foreground">Include this reference in your bank transfer description if possible.</p>
                </div>

                <div className="space-y-2">
                  <Label>Upload Proof of Payment (Screenshot)</Label>
                  <div 
                    className={`relative flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 transition-colors ${proofFile ? 'bg-primary/5 border-primary/50' : 'hover:bg-muted/50'}`}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      if (e.dataTransfer.files?.[0]) setProofFile(e.dataTransfer.files[0]);
                    }}
                  >
                    <input 
                      type="file" 
                      className="absolute inset-0 cursor-pointer opacity-0" 
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files?.[0]) setProofFile(e.target.files[0]);
                      }}
                    />
                    {proofFile ? (
                      <>
                        <CheckCircle2 className="mb-2 h-10 w-10 text-primary" />
                        <p className="text-sm font-medium">{proofFile.name}</p>
                        <p className="text-xs text-muted-foreground">Click or drag to change file</p>
                      </>
                    ) : (
                      <>
                        <Upload className="mb-2 h-10 w-10 text-muted-foreground" />
                        <p className="text-sm font-medium">Click to upload or drag and drop</p>
                        <p className="text-xs text-muted-foreground">PNG, JPG or PDF (max. 5MB)</p>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" className="w-full h-12 text-lg font-bold" disabled={loading}>
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Submit for Verification
                </Button>
              </CardFooter>
            </form>
          </Card>

          <div className="flex items-center gap-3 rounded-lg border p-4 text-sm">
            <ShieldCheck className="h-5 w-5 text-green-500" />
            <p>Your data is encrypted and secure. Payment proofs are only visible to authorized administrators.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
