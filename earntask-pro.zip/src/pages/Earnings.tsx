import React, { useState, useEffect } from 'react';
import { useAuth } from '@/src/components/AuthContext';
import { supabase, UserTask, Withdrawal } from '@/src/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Wallet, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  XCircle,
  ArrowDownToLine,
  Loader2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Earnings() {
  const { user, profile } = useAuth();
  const [userTasks, setUserTasks] = useState<UserTask[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      try {
        const [tasksRes, withdrawalsRes] = await Promise.all([
          supabase.from('user_tasks').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
          supabase.from('withdrawals').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
        ]);

        if (tasksRes.error) throw tasksRes.error;
        if (withdrawalsRes.error) throw withdrawalsRes.error;

        setUserTasks(tasksRes.data || []);
        setWithdrawals(withdrawalsRes.data || []);
      } catch (err) {
        console.error('Error fetching earnings data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
      case 'completed':
        return <Badge className="bg-green-500 hover:bg-green-600">Approved</Badge>;
      case 'pending':
        return <Badge variant="outline" className="text-yellow-500 border-yellow-500">Pending</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const pendingEarnings = userTasks
    .filter(t => t.status === 'pending')
    .reduce((sum, t) => sum + t.reward, 0);

  const totalEarned = userTasks
    .filter(t => t.status === 'approved')
    .reduce((sum, t) => sum + t.reward, 0);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Your Earnings</h1>
          <p className="text-muted-foreground">Track your task rewards and withdrawal history.</p>
        </div>
        <Link to="/withdraw">
          <Button size="lg" className="h-12 px-8 font-bold">
            <ArrowDownToLine className="mr-2 h-5 w-5" />
            Withdraw Funds
          </Button>
        </Link>
      </div>

      {/* Summary Cards */}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Wallet className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Available Balance</p>
                <h3 className="text-2xl font-bold">${profile?.balance?.toFixed(2) || '0.00'}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-500/10 text-yellow-500">
                <Clock className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Approval</p>
                <h3 className="text-2xl font-bold">${pendingEarnings.toFixed(2)}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500/10 text-green-500">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Lifetime Earnings</p>
                <h3 className="text-2xl font-bold">${totalEarned.toFixed(2)}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="tasks" className="space-y-6">
        <TabsList>
          <TabsTrigger value="tasks">Task History</TabsTrigger>
          <TabsTrigger value="withdrawals">Withdrawal History</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks">
          <Card>
            <CardHeader>
              <CardTitle>Completed Tasks</CardTitle>
              <CardDescription>A detailed list of all tasks you've submitted.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 font-bold">Date</th>
                      <th className="px-4 py-3 font-bold">Task ID</th>
                      <th className="px-4 py-3 font-bold">Reward</th>
                      <th className="px-4 py-3 font-bold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {userTasks.map((task) => (
                      <tr key={task.id} className="hover:bg-muted/30">
                        <td className="px-4 py-4 text-muted-foreground">
                          {new Date(task.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-4 font-medium">#{task.task_id.substring(0, 8)}</td>
                        <td className="px-4 py-4 font-bold text-primary">${task.reward.toFixed(2)}</td>
                        <td className="px-4 py-4">{getStatusBadge(task.status)}</td>
                      </tr>
                    ))}
                    {userTasks.length === 0 && (
                      <tr>
                        <td colSpan={4} className="py-8 text-center text-muted-foreground">
                          No tasks found. Start earning by completing tasks!
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="withdrawals">
          <Card>
            <CardHeader>
              <CardTitle>Withdrawal History</CardTitle>
              <CardDescription>Track your payouts to your bank account.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 font-bold">Date</th>
                      <th className="px-4 py-3 font-bold">Amount</th>
                      <th className="px-4 py-3 font-bold">Bank Info</th>
                      <th className="px-4 py-3 font-bold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {withdrawals.map((w) => (
                      <tr key={w.id} className="hover:bg-muted/30">
                        <td className="px-4 py-4 text-muted-foreground">
                          {new Date(w.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-4 font-bold">${w.amount.toFixed(2)}</td>
                        <td className="px-4 py-4">
                          <div className="text-xs">
                            <div className="font-medium">{w.bank_name}</div>
                            <div className="text-muted-foreground">{w.account_number}</div>
                          </div>
                        </td>
                        <td className="px-4 py-4">{getStatusBadge(w.status)}</td>
                      </tr>
                    ))}
                    {withdrawals.length === 0 && (
                      <tr>
                        <td colSpan={4} className="py-8 text-center text-muted-foreground">
                          No withdrawals yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
