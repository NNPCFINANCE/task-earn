import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  CheckCircle2, 
  Users, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  Award,
  ArrowRight,
  Star,
  PlayCircle
} from 'lucide-react';
import { motion } from 'motion/react';

export default function Landing() {
  const stats = [
    { label: 'Active Users', value: '125K+', icon: Users },
    { label: 'Total Paid Out', value: '$2.4M+', icon: TrendingUp },
    { label: 'Tasks Completed', value: '1.8M+', icon: CheckCircle2 },
    { label: 'Trust Score', value: '4.9/5', icon: Star },
  ];

  const features = [
    {
      title: 'Verified Tasks',
      description: 'Every task is manually verified to ensure you get paid for your effort.',
      icon: ShieldCheck,
    },
    {
      title: 'Instant Withdrawals',
      description: 'Once approved, your earnings can be withdrawn directly to your bank account.',
      icon: Zap,
    },
    {
      title: 'Premium Support',
      description: 'Our dedicated team is available 24/7 to help you with any issues.',
      icon: Award,
    },
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Top Earner',
      content: 'I started with the Starter plan and upgraded to Pro within a month. I make about $500 extra every month now!',
      avatar: 'https://picsum.photos/seed/sarah/100/100',
    },
    {
      name: 'Michael Chen',
      role: 'Student',
      content: 'The tasks are simple and the payment is real. Best platform for students looking for side income.',
      avatar: 'https://picsum.photos/seed/michael/100/100',
    },
    {
      name: 'Elena Rodriguez',
      role: 'Freelancer',
      content: 'I love the transparency. The manual verification makes it feel much more secure than other sites.',
      avatar: 'https://picsum.photos/seed/elena/100/100',
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-background py-20 lg:py-32">
        <div className="container relative z-10 mx-auto px-4">
          <div className="flex flex-col items-center text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-4 flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-semibold text-primary"
            >
              <Zap className="h-4 w-4" />
              <span>New: High-paying surveys now available</span>
            </motion.div>
            
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mb-6 max-w-4xl text-5xl font-extrabold tracking-tight md:text-7xl"
            >
              Turn Your Spare Time Into <span className="text-primary">Real Earnings</span>
            </motion.h1>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-10 max-w-2xl text-xl text-muted-foreground"
            >
              Join the world's most trusted task-earning platform. Complete simple digital tasks, surveys, and app tests to earn money daily.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col gap-4 sm:flex-row"
            >
              <Link to="/signup">
                <Button size="lg" className="h-14 px-8 text-lg font-bold shadow-lg shadow-primary/20">
                  Start Earning Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/how-it-works">
                <Button size="lg" variant="outline" className="h-14 px-8 text-lg font-bold">
                  <PlayCircle className="mr-2 h-5 w-5" />
                  See How It Works
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
        
        {/* Background Decoration */}
        <div className="absolute left-1/2 top-1/2 -z-10 h-[800px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/5 blur-3xl" />
      </section>

      {/* Stats Section */}
      <section className="border-y bg-muted/30 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            {stats.map((stat, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <stat.icon className="h-5 w-5" />
                </div>
                <div className="text-3xl font-bold tracking-tight">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-5xl">Why Choose EarnTask Pro?</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              We've built a platform that prioritizes user trust and consistent earnings.
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {features.map((feature, index) => (
              <div key={index} className="rounded-2xl border bg-card p-8 transition-all hover:shadow-xl">
                <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <feature.icon className="h-7 w-7" />
                </div>
                <h3 className="mb-3 text-xl font-bold">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-muted/30 py-24">
        <div className="container mx-auto px-4">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-5xl">What Our Earners Say</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Join thousands of satisfied users who are already making money.
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {testimonials.map((t, index) => (
              <div key={index} className="rounded-2xl bg-background p-8 shadow-sm">
                <div className="mb-6 flex items-center gap-4">
                  <img 
                    src={t.avatar} 
                    alt={t.name} 
                    className="h-12 w-12 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="font-bold">{t.name}</div>
                    <div className="text-sm text-muted-foreground">{t.role}</div>
                  </div>
                </div>
                <p className="italic text-muted-foreground">"{t.content}"</p>
                <div className="mt-4 flex text-yellow-500">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="relative overflow-hidden rounded-3xl bg-primary px-8 py-16 text-center text-primary-foreground md:px-16">
            <div className="relative z-10 mx-auto max-w-3xl">
              <h2 className="mb-6 text-3xl font-bold md:text-5xl">Ready to Start Your Earning Journey?</h2>
              <p className="mb-10 text-xl opacity-90">
                Join EarnTask Pro today and get access to high-paying tasks immediately after verification.
              </p>
              <Link to="/signup">
                <Button size="lg" variant="secondary" className="h-14 px-10 text-lg font-bold">
                  Create Free Account
                </Button>
              </Link>
            </div>
            
            {/* Decoration */}
            <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          </div>
        </div>
      </section>
    </div>
  );
}
