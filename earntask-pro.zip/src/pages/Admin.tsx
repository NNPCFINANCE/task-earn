import React, { useState, useEffect } from 'react';
import { useAuth } from '@/src/components/AuthContext';
import { supabase, Profile, Payment, Task, UserTask, Withdrawal } from '@/src/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  CreditCard, 
  CheckSquare, 
  ArrowDownToLine, 
  Plus, 
  Trash2, 
  Check, 
  X,
  Loader2,
  ExternalLink
} from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function Admin() {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  
  // New Task State
  const [newTask, setNewTask] = useState({ title: '', description: '', reward: '', type: 'social' });

  useEffect(() => {
    if (!profile?.is_admin) return;
    fetchAdminData();
  }, [profile]);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [paymentsRes, tasksRes, usersRes, withdrawalsRes] = await Promise.all([
        supabase.from('payments').select('*').order('created_at', { ascending: false }),
        supabase.from('tasks').select('*').order('created_at', { ascending: false }),
        supabase.from('profiles').select('*').order('created_at', { ascending: false }),
        supabase.from('withdrawals').select('*').order('created_at', { ascending: false })
      ]);

      setPayments(paymentsRes.data || []);
      setTasks(tasksRes.data || []);
      setUsers(usersRes.data || []);
      setWithdrawals(withdrawalsRes.data || []);
    } catch (err) {
      console.error('Error fetching admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprovePayment = async (payment: Payment) => {
    try {
      // 1. Update payment status
      const { error: payError } = await supabase
        .from('payments')
        .update({ status: 'approved' })
        .eq('id', payment.id);

      if (payError) throw payError;

      // 2. Update user plan
      const { error: userError } = await supabase
        .from('profiles')
        .update({ plan: payment.plan_id })
        .eq('id', payment.user_id);

      if (userError) throw userError;

      toast.success('Payment approved and plan activated!');
      fetchAdminData();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleAddTask = async () => {
    try {
      const { error } = await supabase
        .from('tasks')
        .insert([{
          title: newTask.title,
          description: newTask.description,
          reward: parseFloat(newTask.reward),
          type: newTask.type,
          status: 'active'
        }]);

      if (error) throw error;
      toast.success('Task added successfully!');
      setNewTask({ title: '', description: '', reward: '', type: 'social' });
      fetchAdminData();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleCompleteWithdrawal = async (w: Withdrawal) => {
    try {
      const { error } = await supabase
        .from('withdrawals')
        .update({ status: 'completed' })
        .eq('id', w.id);

      if (error) throw error;
      toast.success('Withdrawal marked as completed!');
      fetchAdminData();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  if (!profile?.is_admin) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-destructive">Access Denied</h1>
        <p>You do not have permission to view this page.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Admin Control Panel</h1>
        <p className="text-muted-foreground">Manage users, payments, tasks and withdrawals.</p>
      </div>

      <Tabs defaultValue="payments" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:w-[600px]">
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
        </TabsList>

        {/* Payments Tab */}
        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>Subscription Payments</CardTitle>
              <CardDescription>Review and approve manual payment proofs.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-muted text-xs uppercase">
                    <tr>
                      <th className="px-4 py-3">User</th>
                      <th className="px-4 py-3">Plan</th>
                      <th className="px-4 py-3">Amount</th>
                      <th className="px-4 py-3">Proof</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {payments.map((p) => (
                      <tr key={p.id} className="hover:bg-muted/30">
                        <td className="px-4 py-4">
                          <div className="text-xs">
                            <div className="font-bold">{p.payer_name}</div>
                            <div className="text-muted-foreground">{p.reference}</div>
                          </div>
                        </td>
                        <td className="px-4 py-4 uppercase font-bold text-xs">{p.plan_id}</td>
                        <td className="px-4 py-4 font-bold">${p.amount.toFixed(2)}</td>
                        <td className="px-4 py-4">
                          <a href={p.proof_url} target="_blank" rel="noreferrer" className="text-primary hover:underline flex items-center gap-1">
                            View <ExternalLink className="h-3 w-3" />
                          </a>
                        </td>
                        <td className="px-4 py-4">
                          <Badge variant={p.status === 'approved' ? 'default' : 'outline'}>{p.status}</Badge>
                        </td>
                        <td className="px-4 py-4">
                          {p.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button size="sm" className="h-8 w-8 p-0" onClick={() => handleApprovePayment(p)}>
                                <Check className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="destructive" className="h-8 w-8 p-0">
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tasks Tab */}
        <TabsContent value="tasks">
          <div className="mb-6 flex justify-end">
            <Dialog>
              <DialogTrigger asChild>
                <Button><Plus className="mr-2 h-4 w-4" /> Add New Task</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Task</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input value={newTask.title} onChange={(e) => setNewTask({...newTask, title: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input value={newTask.description} onChange={(e) => setNewTask({...newTask, description: e.target.value})} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Reward ($)</Label>
                      <Input type="number" value={newTask.reward} onChange={(e) => setNewTask({...newTask, reward: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <select 
                        className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                        value={newTask.type}
                        onChange={(e) => setNewTask({...newTask, type: e.target.value})}
                      >
                        <option value="social">Social</option>
                        <option value="download">Download</option>
                        <option value="survey">Survey</option>
                      </select>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddTask}>Create Task</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>Manage Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-muted text-xs uppercase">
                    <tr>
                      <th className="px-4 py-3">Task</th>
                      <th className="px-4 py-3">Type</th>
                      <th className="px-4 py-3">Reward</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {tasks.map((t) => (
                      <tr key={t.id} className="hover:bg-muted/30">
                        <td className="px-4 py-4 font-medium">{t.title}</td>
                        <td className="px-4 py-4 uppercase text-xs">{t.type}</td>
                        <td className="px-4 py-4 font-bold text-primary">${t.reward.toFixed(2)}</td>
                        <td className="px-4 py-4">
                          <Badge variant={t.status === 'active' ? 'default' : 'secondary'}>{t.status}</Badge>
                        </td>
                        <td className="px-4 py-4">
                          <Button variant="ghost" size="sm" className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>Platform Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-muted text-xs uppercase">
                    <tr>
                      <th className="px-4 py-3">User</th>
                      <th className="px-4 py-3">Plan</th>
                      <th className="px-4 py-3">Balance</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Joined</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-muted/30">
                        <td className="px-4 py-4">
                          <div className="text-xs">
                            <div className="font-bold">{u.full_name}</div>
                            <div className="text-muted-foreground">{u.email}</div>
                          </div>
                        </td>
                        <td className="px-4 py-4 uppercase font-bold text-xs">{u.plan}</td>
                        <td className="px-4 py-4 font-bold text-primary">${u.balance.toFixed(2)}</td>
                        <td className="px-4 py-4">
                          <Badge variant={u.status === 'active' ? 'default' : 'destructive'}>{u.status}</Badge>
                        </td>
                        <td className="px-4 py-4 text-muted-foreground">
                          {new Date(u.created_at).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Withdrawals Tab */}
        <TabsContent value="withdrawals">
          <Card>
            <CardHeader>
              <CardTitle>Pending Withdrawals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-muted text-xs uppercase">
                    <tr>
                      <th className="px-4 py-3">User</th>
                      <th className="px-4 py-3">Amount</th>
                      <th className="px-4 py-3">Bank Details</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {withdrawals.map((w) => (
                      <tr key={w.id} className="hover:bg-muted/30">
                        <td className="px-4 py-4 font-medium">#{w.user_id.substring(0, 8)}</td>
                        <td className="px-4 py-4 font-bold text-primary">${w.amount.toFixed(2)}</td>
                        <td className="px-4 py-4">
                          <div className="text-xs">
                            <div className="font-bold">{w.bank_name}</div>
                            <div className="text-muted-foreground">{w.account_number}</div>
                            <div className="text-muted-foreground italic">{w.account_name}</div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <Badge variant={w.status === 'completed' ? 'default' : 'outline'}>{w.status}</Badge>
                        </td>
                        <td className="px-4 py-4">
                          {w.status === 'pending' && (
                            <Button size="sm" onClick={() => handleCompleteWithdrawal(w)}>
                              Mark Completed
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
