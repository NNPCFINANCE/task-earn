import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, Zap, ShieldCheck, Award, Star } from 'lucide-react';
import { motion } from 'motion/react';

export default function Pricing() {
  const plans = [
    {
      id: 'starter',
      name: 'Starter',
      price: 10,
      description: 'Perfect for beginners starting their earning journey.',
      daily_limit: 5,
      monthly_est: 45,
      features: [
        'Access to Social Media Tasks',
        'Standard Support',
        'Weekly Withdrawals',
        'Basic Dashboard',
      ],
      icon: Zap,
      color: 'text-blue-500',
      bg: 'bg-blue-500/10',
    },
    {
      id: 'growth',
      name: 'Growth',
      price: 25,
      description: 'Our most popular plan for consistent daily earners.',
      daily_limit: 15,
      monthly_est: 150,
      features: [
        'All Starter Features',
        'Access to App Download Tasks',
        'Priority Support',
        'Daily Withdrawals',
        '10% Referral Bonus',
      ],
      icon: Award,
      color: 'text-primary',
      bg: 'bg-primary/10',
      popular: true,
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 50,
      description: 'For serious earners who want maximum daily rewards.',
      daily_limit: 'Unlimited',
      monthly_est: 450,
      features: [
        'All Growth Features',
        'Exclusive High-Reward Surveys',
        '24/7 Dedicated Manager',
        'Instant Withdrawals',
        '20% Referral Bonus',
        'Early Access to New Tasks',
      ],
      icon: Star,
      color: 'text-yellow-500',
      bg: 'bg-yellow-500/10',
    },
  ];

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="mb-16 text-center">
        <h1 className="mb-4 text-4xl font-extrabold tracking-tight md:text-6xl">Choose Your Earning Power</h1>
        <p className="mx-auto max-w-2xl text-xl text-muted-foreground">
          Select a subscription plan that fits your goals. Higher plans unlock more tasks and bigger rewards.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {plans.map((plan, index) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative"
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 rounded-full bg-primary px-4 py-1 text-sm font-bold text-primary-foreground shadow-lg">
                MOST POPULAR
              </div>
            )}
            <Card className={`flex h-full flex-col shadow-xl transition-all hover:scale-[1.02] ${plan.popular ? 'border-2 border-primary ring-4 ring-primary/10' : ''}`}>
              <CardHeader>
                <div className={`mb-4 flex h-12 w-12 items-center justify-center rounded-xl ${plan.bg} ${plan.color}`}>
                  <plan.icon className="h-6 w-6" />
                </div>
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="mb-6">
                  <span className="text-4xl font-extrabold">${plan.price}</span>
                  <span className="text-muted-foreground">/one-time</span>
                </div>
                
                <div className="mb-6 space-y-2 rounded-lg bg-muted/50 p-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Daily Task Limit:</span>
                    <span className="font-bold">{plan.daily_limit}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Est. Monthly Earnings:</span>
                    <span className="font-bold text-green-600">${plan.monthly_est}+</span>
                  </div>
                </div>

                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Link to={`/payment?plan=${plan.id}`} className="w-full">
                  <Button className="w-full" variant={plan.popular ? 'default' : 'outline'} size="lg">
                    Subscribe to {plan.name}
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="mt-20 rounded-3xl border bg-card p-8 md:p-12">
        <div className="grid grid-cols-1 items-center gap-12 md:grid-cols-2">
          <div>
            <h2 className="mb-4 text-3xl font-bold">Why is there a subscription fee?</h2>
            <p className="mb-6 text-muted-foreground">
              The subscription fee helps us maintain a high-quality platform, verify every task manually, and ensure that our earners are real people. This prevents botting and allows us to offer higher rewards for every task you complete.
            </p>
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <div>
                <div className="font-bold">100% Money Back Guarantee</div>
                <div className="text-sm text-muted-foreground">If you don't earn back your fee in 30 days.</div>
              </div>
            </div>
          </div>
          <div className="relative aspect-video overflow-hidden rounded-2xl shadow-2xl">
            <img 
              src="https://picsum.photos/seed/earning/800/450" 
              alt="Earning dashboard" 
              className="h-full w-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
              <p className="text-white font-medium italic">"The best investment I made this year. Earned back my Pro fee in just 4 days!"</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
