/// <reference types="vite/client" />
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://adlbaxkezdqoxkupxwvb.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_QOFt047KNeammiTBFPKO-g_CtJ7PFWw';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase credentials missing. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your environment variables.');
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder-key'
);

export type Profile = {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  plan: 'free' | 'starter' | 'growth' | 'pro';
  balance: number;
  status: 'active' | 'suspended';
  is_admin: boolean;
  created_at: string;
};

export type Plan = {
  id: string;
  name: string;
  price: number;
  daily_task_limit: number;
  estimated_monthly_earnings: number;
  features: string[];
};

export type Payment = {
  id: string;
  user_id: string;
  plan_id: string;
  amount: number;
  reference: string;
  payer_name: string;
  proof_url: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
};

export type Task = {
  id: string;
  title: string;
  description: string;
  reward: number;
  type: 'social' | 'download' | 'survey';
  status: 'active' | 'inactive';
  created_at: string;
};

export type UserTask = {
  id: string;
  user_id: string;
  task_id: string;
  proof_url: string;
  status: 'pending' | 'approved' | 'rejected';
  reward: number;
  created_at: string;
};

export type Withdrawal = {
  id: string;
  user_id: string;
  amount: number;
  bank_name: string;
  account_number: string;
  account_name: string;
  status: 'pending' | 'completed' | 'rejected';
  created_at: string;
};
