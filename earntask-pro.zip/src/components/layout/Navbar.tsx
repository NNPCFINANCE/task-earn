import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/src/components/AuthContext';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, 
  LogOut, 
  User as UserIcon, 
  Wallet, 
  CheckSquare, 
  ShieldCheck,
  Menu,
  X
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { useState } from 'react';

export function Navbar() {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold tracking-tight">EarnTask Pro</span>
          </Link>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex md:items-center md:gap-6">
          {user ? (
            <>
              <Link to="/dashboard" className="text-sm font-medium transition-colors hover:text-primary">
                Dashboard
              </Link>
              <Link to="/tasks" className="text-sm font-medium transition-colors hover:text-primary">
                Tasks
              </Link>
              <Link to="/earnings" className="text-sm font-medium transition-colors hover:text-primary">
                Earnings
              </Link>
              {profile?.is_admin && (
                <Link to="/admin" className="text-sm font-medium text-destructive transition-colors hover:text-destructive/80">
                  Admin
                </Link>
              )}
              <div className="flex items-center gap-4 border-l pl-6">
                <div className="flex flex-col items-end">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Balance</span>
                  <span className="text-sm font-bold text-primary">${profile?.balance?.toFixed(2) || '0.00'}</span>
                </div>
                <Link to="/profile">
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <UserIcon className="h-5 w-5" />
                  </Button>
                </Link>
                <Button variant="outline" size="sm" onClick={handleSignOut}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </Button>
              </div>
            </>
          ) : (
            <>
              <Link to="/how-it-works" className="text-sm font-medium transition-colors hover:text-primary">
                How It Works
              </Link>
              <Link to="/pricing" className="text-sm font-medium transition-colors hover:text-primary">
                Pricing
              </Link>
              <div className="flex items-center gap-4 border-l pl-6">
                <Link to="/login">
                  <Button variant="ghost" size="sm">Login</Button>
                </Link>
                <Link to="/signup">
                  <Button size="sm">Get Started</Button>
                </Link>
              </div>
            </>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="border-b bg-background p-4 md:hidden">
          <div className="flex flex-col gap-4">
            {user ? (
              <>
                <Link to="/dashboard" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 text-sm font-medium">
                  <LayoutDashboard className="h-4 w-4" /> Dashboard
                </Link>
                <Link to="/tasks" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 text-sm font-medium">
                  <CheckSquare className="h-4 w-4" /> Tasks
                </Link>
                <Link to="/earnings" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 text-sm font-medium">
                  <Wallet className="h-4 w-4" /> Earnings
                </Link>
                {profile?.is_admin && (
                  <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 text-sm font-medium text-destructive">
                    <ShieldCheck className="h-4 w-4" /> Admin
                  </Link>
                )}
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-xs text-muted-foreground">Balance</span>
                    <span className="font-bold">${profile?.balance?.toFixed(2) || '0.00'}</span>
                  </div>
                  <Link to="/profile" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="outline" size="sm">Profile</Button>
                  </Link>
                </div>
                <Button variant="destructive" size="sm" onClick={handleSignOut} className="w-full">
                  <LogOut className="mr-2 h-4 w-4" /> Sign Out
                </Button>
              </>
            ) : (
              <>
                <Link to="/how-it-works" onClick={() => setIsMenuOpen(false)} className="text-sm font-medium">How It Works</Link>
                <Link to="/pricing" onClick={() => setIsMenuOpen(false)} className="text-sm font-medium">Pricing</Link>
                <Separator />
                <Link to="/login" onClick={() => setIsMenuOpen(false)}>
                  <Button variant="outline" className="w-full">Login</Button>
                </Link>
                <Link to="/signup" onClick={() => setIsMenuOpen(false)}>
                  <Button className="w-full">Get Started</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
